DROP table ng_users;
DROP table ng_albums;
DROP table ng_singers;
